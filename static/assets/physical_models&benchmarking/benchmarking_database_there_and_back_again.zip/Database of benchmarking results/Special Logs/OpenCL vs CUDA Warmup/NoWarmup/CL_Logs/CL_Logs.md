# CL_Logs

This directory will be populated with results from the benchmarking suite for the OpenCL implementations.