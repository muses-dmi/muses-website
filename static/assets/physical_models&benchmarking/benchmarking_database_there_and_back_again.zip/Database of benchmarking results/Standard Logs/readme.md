# Standard Logs

This directory contains all the different systems the benchmarking suite was executed on. We have separated the logged files into (hopefully) self-explanatory directories to assist navigation. 

## Directory Structure

This folder contains the device name
along with a device type which is either "discrete" or "integrated", this indicates the type of GPU it is. Inside these directories are the paths to the OpenCL and CUDA logs. All devices here support OpenCL, so will have a 
"CL_Logs" directory containing profiles for OpenCL. Only the NVIDIA devices support and therefore contain results for "CUDA_Logs". Inside there will be the "general" benchmarks and the "real-time" benchmarks. Inside "general" benchmarks
are files indicating the number of repetitions, usually a small number to allow testing of larger buffer sizes and a large repetition set. Inside these directories are the different buffer sizes running all the tests for the set number
of repetitions. Back to the "real-time" directory, this first contains directories indicating the framerate tested. Inside these are all the real-time tests, which contain all the different buffer sizes possible within the framerate and
their results for that test.

## File Structure

All the benchmarking files (Excluding the "cl_mappingmemory" test) test have the same measurements recorded. These files contain the "Total_Time" to execute all tests for the number of repetitions, the "Average_Time" across the repetitions,
the "Max_Time" recorded, the "Min_Time" recorded, the "Max_Difference" being the maximum difference between to consecutive tests (Consider this as max jitter and the "Average_Difference" (Consider this the average jitter).
The general benchmarking tests contain these measurements for the set number of repetitions. For the "general" benchmarks, each file contains all the test run at buffer size in the file name. For the "real-time" benchmarks, the file contains
all the buffer sizes run for the indicated test in the file name. (Basically the other way around to the "general" files)

## cl_mappingmemory

There is one anomaly to this structure for the OpenCL API. OpenCL requires explicit mapping of pinned memory. Therefore, tests measuring the time to "map", "unmap", "write" standard memory vs "mapwrite" pinned memory, "read" standard
memory vs "mapread" pinned memory and standard "writeread" to "mapwriteread" pinned memory. These were all run for 100 repetitions. They aim to measure the difference between going through mapping and unmapping to write to pinned memory
to just using standard memory. CUDA does not follow this design and therefore no similar test was added.